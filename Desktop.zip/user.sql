/*
SQLyog Ultimate v12.09 (64 bit)
MySQL - 5.7.21-log : Database - bank
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`bank` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `bank`;

/*Table structure for table `account` */

DROP TABLE IF EXISTS `account`;

CREATE TABLE `account` (
  `accountid` int(4) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `balance` decimal(18,2) DEFAULT NULL,
  `status` int(4) DEFAULT NULL,
  PRIMARY KEY (`accountid`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

/*Data for the table `account` */

insert  into `account`(`accountid`,`username`,`password`,`balance`,`status`) values (1,'1016041135','12345','11299.00',1),(2,'B12110931','123456','1100.00',1),(3,'B12110901','123456','1000.00',1),(4,'B12110902','123456','1000.00',1),(5,'B12110903','123456','1000.00',1),(6,'B12110904','123456','1000.00',1),(7,'B12110905','123456','1000.00',2),(8,'B12110906','123456','1000.00',1),(9,'B12110907','123456','1000.00',1),(10,'B12110908','123456','1000.00',1),(11,'B12110909','123456','1000.00',1),(15,'B12110913','123456','900.00',1),(16,'1234567','123456','10000020000.00',1);

/*Table structure for table `admin` */

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `money` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

/*Data for the table `admin` */

insert  into `admin`(`id`,`username`,`password`,`money`) values (1,'admin','123456',11111111512);

/*Table structure for table `loan_log` */

DROP TABLE IF EXISTS `loan_log`;

CREATE TABLE `loan_log` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `accountid` int(4) DEFAULT NULL,
  `loan_money` decimal(18,0) DEFAULT NULL,
  `datetime` varchar(50) DEFAULT NULL,
  `huan_money` decimal(18,0) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

/*Data for the table `loan_log` */

insert  into `loan_log`(`id`,`accountid`,`loan_money`,`datetime`,`huan_money`) values (1,1,'700','2017-7-19 16:45:9','0'),(2,2,'900','2017-7-19 16:45:9','200'),(3,1,'399','2019-06-21 14:58:07','399'),(4,16,'10000','2019-06-21 16:16:14','10000');

/*Table structure for table `personinfo` */

DROP TABLE IF EXISTS `personinfo`;

CREATE TABLE `personinfo` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `accountid` int(4) DEFAULT NULL,
  `realname` varchar(50) DEFAULT NULL,
  `age` int(4) DEFAULT NULL,
  `sex` varchar(2) DEFAULT NULL,
  `cardid` decimal(18,0) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `telephone` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

/*Data for the table `personinfo` */

insert  into `personinfo`(`id`,`accountid`,`realname`,`age`,`sex`,`cardid`,`address`,`telephone`) values (1,1,'程阳',21,'男','320542000000000001','南邮','15810000001'),(2,2,'赵强',23,'男','320542000000000002','湖北武汉','15810000002'),(3,3,'程阳',22,'男','320542000000000001','南邮','15810000001'),(4,4,'程阳',22,'男','320542000000000001','南邮','15810000001'),(5,5,'程阳',22,'男','320542000000000001','南邮','15810000001'),(6,6,'程阳',22,'男','320542000000000001','南邮','15810000001'),(7,7,'程阳',22,'男','320542000000000001','南邮','15810000001'),(8,8,'程阳',22,'男','320542000000000001','南邮','15810000001'),(9,9,'程阳',22,'男','320542000000000001','南邮','15810000001'),(10,10,'程阳',22,'男','320542000000000001','南邮','15810000001'),(15,15,'张三',23,'女','320542000000000003','江苏南京','18362837211'),(16,16,'周洪庆',21,'男','371311199802043135','枣庄学院教务处','17863276395');

/*Table structure for table `status` */

DROP TABLE IF EXISTS `status`;

CREATE TABLE `status` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `status` */

insert  into `status`(`id`,`name`) values (1,'启用'),(2,'冻结');

/*Table structure for table `transaction_log` */

DROP TABLE IF EXISTS `transaction_log`;

CREATE TABLE `transaction_log` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `accountid` int(4) DEFAULT NULL,
  `otherid` int(4) DEFAULT NULL,
  `tr_money` decimal(18,0) DEFAULT NULL,
  `datetime` varchar(50) DEFAULT NULL,
  `ta_type` int(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

/*Data for the table `transaction_log` */

insert  into `transaction_log`(`id`,`accountid`,`otherid`,`tr_money`,`datetime`,`ta_type`) values (1,1,1,'200','2017-7-19 16:45:9',1),(2,1,1,'100','2019-6-20 11:19:53',1),(3,1,1,'10000','2019-6-21 13:13:22',1),(4,1,2,'100','2019-6-21 13:15:9',3),(5,16,16,'10000','2019-6-21 16:16:4',1);

/*Table structure for table `transaction_type` */

DROP TABLE IF EXISTS `transaction_type`;

CREATE TABLE `transaction_type` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

/*Data for the table `transaction_type` */

insert  into `transaction_type`(`id`,`name`) values (1,'存款'),(2,'取款'),(3,'转账');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
