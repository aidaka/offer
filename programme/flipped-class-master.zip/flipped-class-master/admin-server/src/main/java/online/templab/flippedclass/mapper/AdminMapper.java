package online.templab.flippedclass.mapper;

import online.templab.flippedclass.entity.Admin;
import org.springframework.stereotype.Component;
import tk.mybatis.mapper.common.Mapper;

/**
 * @author wk
 */
@Component
public interface AdminMapper extends Mapper<Admin> {
}