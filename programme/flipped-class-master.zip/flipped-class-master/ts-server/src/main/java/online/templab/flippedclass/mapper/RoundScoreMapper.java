package online.templab.flippedclass.mapper;

import online.templab.flippedclass.entity.RoundScore;
import org.springframework.stereotype.Component;
import tk.mybatis.mapper.common.Mapper;

/**
 * @author wk
 */
@Component
public interface RoundScoreMapper extends Mapper<RoundScore> {
}