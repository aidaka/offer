# Demo Picture


## 演示图片
以下图片仅为系统的部分截图。

#### 用户登录
![用户登录](demo-picture/login.jpg)

#### 查看课程列表
![查看课程](demo-picture/course-list.jpg)

#### 查看课程信息
![查看课程信息](demo-picture/course-info.jpg)

#### 报名讨论课
![报名讨论课](demo-picture/enroll-list.jpg)

#### 查看成绩
![查看成绩](demo-picture/grade.jpg)

#### 查看班级
![klass-list](demo-picture/klass-list.jpg)

#### 查看具体的一个讨论课
![查看具体的一个讨论课](demo-picture/seminar-list-detail.jpg)

#### 查看队伍
![查看队伍](demo-picture/team-list.jpg)

#### 管理员管理中心
![管理员管理中心](demo-picture/admin-index.jpg)